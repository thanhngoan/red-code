// TabooTest.java
// Taboo class tests -- nothing provided.

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import junit.framework.TestCase;

public class TabooTest extends TestCase {
}
