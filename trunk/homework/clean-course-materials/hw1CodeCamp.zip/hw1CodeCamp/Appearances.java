import java.util.*;

public class Appearances {
	/**
	 * Returns the number of elements that appear the same number
	 * of times in both collections. Static method. (see handout).
	 * @return number of same-appearance elements
	 */
	public static int sameCount(Collection<?> a, Collection<?> b) {
		return 0;
	}
	
}
